import os
from random import randint
from flask import Flask, render_template, redirect, request
from flask_login import LoginManager, login_user, login_required, logout_user
from flask_login import current_user

from data import db_session
from data.newmeme import AddMeme
from data.newgroup import AddGroup
from data.newhero import AddHero
from data.newsong import AddSong
from data.login_form import LoginForm
from data.users import User
from data.meme import Meme
from data.hero import Hero
from data.song import Song
from data.register import RegisterForm

UPLOAD_FOLDER = '/pictures'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

login_manager = LoginManager()
login_manager.init_app(app)


def main():
    db_session.global_init("db/wiki.sqlite")
    
    def allowed_file(filename):
        return '.' in filename and \
               filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

    @login_manager.user_loader
    def load_user(user_id):
        session = db_session.create_session()
        return session.query(User).get(user_id)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        form = LoginForm()
        if form.validate_on_submit():
            session = db_session.create_session()
            user = session.query(User).filter(User.email == form.email.data).first()
            if user and user.check_password(form.password.data):
                login_user(user, remember=form.remember_me.data)
                return redirect("/")
            return render_template('login.html', message="Неправильный логин или пароль", form=form)
        return render_template('login.html', title='Вход', form=form)

    @app.route("/")
    def index():
        session = db_session.create_session()
        return render_template("index.html")

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect("/")

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        form = RegisterForm()
        if form.validate_on_submit():
            if form.password.data != form.password_again.data:
                return render_template('register.html', title='Регистрация', form=form,
                                       message="Вы ввели два разных пароля")
            session = db_session.create_session()
            if session.query(User).filter(User.email == form.email.data).first():
                return render_template('register.html', title='Регистрация', form=form,
                                       message="На эту почту уже зарегистрирован участник")
            user = User(
                name=form.name.data,
                email=form.email.data
            )
            user.set_password(form.password.data)
            session.add(user)
            session.commit()
            return redirect('/login')
        return render_template('register.html', title='Регистрация', form=form)
    
    @app.route("/profile")
    def profile():
        if current_user.is_authenticated:
            mail = 'Электронная почта: ' + current_user.email
            return render_template("profile.html", username=current_user.name, info=mail)               
        return redirect('/register')
    
    @app.route('/addmeme', methods=['GET', 'POST'])
    @login_required
    def addmeme():
        add_form = AddMeme()
        if add_form.validate_on_submit():
            session = db_session.create_session()
            meme = Meme(
                title=add_form.title.data,
                date=add_form.date.data,
                author=add_form.author.data,
                people=add_form.people.data,
                period=add_form.period.data,
                status=add_form.status.data,
                about=add_form.about.data,
                history=add_form.history.data,
                connected=add_form.connected.data
            )
            session.add(meme)
            session.commit()
            return redirect('/')
        return render_template('newmeme.html', 
                               title='Новая статья про мем', form=add_form)    
    
    @app.route('/addgroup', methods=['GET', 'POST'])
    @login_required
    def addgroup():
        add_form = AddGroup()
        if add_form.validate_on_submit():
            session = db_session.create_session()
            group = Meme(
                title=add_form.title.data,
                date=add_form.date.data,
                author=add_form.author.data,
                people=add_form.people.data,
                period=add_form.period.data,
                status=add_form.status.data,
                about=add_form.about.data,
                history=add_form.history.data,
                connected=add_form.connected.data
            )
            session.add(group)
            session.commit()
            return redirect('/')
        return render_template('newgroup.html', 
                               title='Новая статья про группу', form=add_form)    
    
    @app.route('/addhero', methods=['GET', 'POST'])
    @login_required
    def addhero():
        add_form = AddHero()
        if add_form.validate_on_submit():
            session = db_session.create_session()
            hero = Hero(
                title=add_form.title.data,
                fullname=add_form.fullname.data,
                is_real=add_form.is_real.data,
                race=add_form.race.data,
                period=add_form.period.data,
                biography=add_form.biography.data,
                connected=add_form.connected.data
            )
            session.add(hero)
            session.commit()
            return redirect('/')
        return render_template('newhero.html', 
                               title='Новая статья про персонажа', 
                               form=add_form)    
    
    @app.route('/addsong', methods=['GET', 'POST'])
    @login_required
    def addsong():
        add_form = AddSong()
        if add_form.validate_on_submit():
            session = db_session.create_session()
            song = Song(
                title=add_form.title.data,
                fulltitle=add_form.fulltitle.data,
                author=add_form.author.data,
                album=add_form.album.data,
                year=add_form.year.data,
                period=add_form.period.data,
                history=add_form.history.data,
                connected=add_form.connected.data
            )
            session.add(song)
            session.commit()
            return redirect('/')
        return render_template('newsong.html', 
                               title='Новая статья про песню', 
                               form=add_form)      
    
    @app.route('/check', methods=['GET', 'POST'])
    @login_required
    def check():
        if (current_user.email == 'olhov.i@liceum1535.ru' or 
            current_user.email == 'sobolev.r@liceum1535.ru'):
            session = db_session.create_session()
            memes = session.query(Meme).filter(Meme.is_public.is_(False)).all()
            heroes = session.query(Hero).filter(Hero.is_public.is_(False)).all()
            songs = session.query(Song).filter(Song.is_public.is_(False)).all()
            return render_template('check.html', 
                                   memes=memes, heroes=heroes, songs=songs)
        return redirect('/')
    
    @app.route('/allpages', methods=['GET', 'POST'])
    def allpages():
        session = db_session.create_session()
        memes = session.query(Meme).filter(Meme.is_public.is_(True)).all()
        heroes = session.query(Hero).filter(Hero.is_public.is_(True)).all()
        songs = session.query(Song).filter(Song.is_public.is_(True)).all()    
        return render_template('allpages.html', memes=memes, heroes=heroes,
                               songs=songs)
    
    @app.route('/submit/meme<page_id>', methods=['GET', 'POST'])
    def submitmeme(page_id):
        session = db_session.create_session()
        meme = session.query(Meme).filter(Meme.id == page_id).first()
        meme.is_public = True
        session.commit()
        return redirect('/check')
    
    @app.route('/submit/hero<page_id>', methods=['GET', 'POST'])
    def submithero(page_id):
        session = db_session.create_session()
        hero = session.query(Hero).filter(Hero.id == page_id).first()
        hero.is_public = True
        session.commit()
        return redirect('/check')    
    
    @app.route('/submit/song<page_id>', methods=['GET', 'POST'])
    def submitsong(page_id):
        session = db_session.create_session()
        song = session.query(Song).filter(Song.id == page_id).first()
        song.is_public = True
        session.commit()
        return redirect('/check')
    
    @app.route('/delete/meme<page_id>', methods=['GET', 'POST'])
    def deletememe(page_id):
        session = db_session.create_session()
        meme = session.query(Meme).filter(Meme.id == page_id).first()
        session.delete(meme)
        session.commit()
        return redirect('/check')
    
    @app.route('/delete/hero<page_id>', methods=['GET', 'POST'])
    def deletehero(page_id):
        session = db_session.create_session()
        hero = session.query(Hero).filter(Hero.id == page_id).first()
        session.delete(hero)
        session.commit()
        return redirect('/check')    
    
    @app.route('/delete/song<page_id>', methods=['GET', 'POST'])
    def deletesong(page_id):
        session = db_session.create_session()
        song = session.query(Song).filter(Song.id == page_id).first()
        session.delete(song)
        session.commit()
        return redirect('/check')
    
    @app.route('/<title>', methods=['GET', 'POST'])
    def category(title):
        session = db_session.create_session()
        if title == 'memes':
            pagetitle = 'Мемы и группы'
            description = 'Основной вид мемов в нашем классе - группы в '
            description += 'WhatsApp, в которых мем выражается с помощью '
            description += 'названия группы, её аватарки и описания. Также '
            description += 'есть мемы, не являющиеся группами.'
            pagetype = 'meme'
            pages = session.query(Meme).filter(Meme.is_public.is_(True)).all()
        elif title == 'heroes':
            pagetitle = 'Персонажи'
            description = 'Персонажи, являющиеся популярными героями мемов. '
            description += 'Как реальные, так и выдуманные.'
            pagetype = 'hero'
            pages = session.query(Hero).filter(Hero.is_public.is_(True)).all()
        elif title == 'songs':
            pagetitle = 'Песни'
            description = 'Песни, ставшие мемами.'
            pagetype = 'song'
            pages = session.query(Song).filter(Song.is_public.is_(True)).all()
        else:
            return redirect('/')
        return render_template('category.html', title=pagetitle,
                               description=description, pagetype=pagetype,
                               pages=pages)
    
    @app.route('/members', methods=['GET', 'POST'])
    def members():
        session = db_session.create_session()
        users = session.query(User).all()
        return render_template('members.html', users=users)
    
    @app.route('/memepage<page_id>', methods=['GET', 'POST'])
    def meme(page_id):
        session = db_session.create_session()
        meme = session.query(Meme).filter(Meme.id == page_id).first()
        imglink = '/pictures/' + str(page_id) + '.png'
        return render_template('meme.html', meme=meme, imglink=imglink)    
    
    @app.route('/heropage<page_id>', methods=['GET', 'POST'])
    def hero(page_id):
        session = db_session.create_session()
        hero = session.query(Hero).filter(Hero.id == page_id).first()
        imglink = '/pictures/' + str(page_id) + '.png'
        return render_template('character.html', hero=hero, imglink=imglink)        
    
    @app.route('/songpage<page_id>', methods=['GET', 'POST'])
    def song(page_id):
        session = db_session.create_session()
        song = session.query(Song).filter(Song.id == page_id).first()
        imglink = '/pictures/' + str(page_id) + '.png'
        return render_template('song.html', song=song, imglink=imglink)   
    
    app.run(port=8080, host='127.0.0.1')


if __name__ == '__main__':
    main()